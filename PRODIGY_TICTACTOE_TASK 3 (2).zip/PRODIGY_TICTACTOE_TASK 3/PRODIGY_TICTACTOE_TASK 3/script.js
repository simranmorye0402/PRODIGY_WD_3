let currentPlayer = 'X';
let board = ['', '', '', '', '', '', '', '', ''];
const winCombinations = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [0, 3, 6], [1, 4, 7], [2, 5, 8],
    [0, 4, 8], [2, 4, 6]
];

function makeMove(index) {
    if (board[index] === '' && !checkWinner()) {
        board[index] = currentPlayer;
        document.getElementsByClassName('cell')[index].innerText = currentPlayer;
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        updateMessage();
        checkWinner();
    }
}

function updateMessage() {
    document.getElementById('message').innerText = `Player ${currentPlayer}'s turn`;
}

function checkWinner() {
    for (const combination of winCombinations) {
        const [a, b, c] = combination;
        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            document.getElementById('message').innerText = `Player ${board[a]} wins!`;
            return true;
        }
    }
    if (!board.includes('')) {
        document.getElementById('message').innerText = "It's a draw!";
        return true;
    }
    return false;
}

function resetGame() {
    board = ['', '', '', '', '', '', '', '', ''];
    currentPlayer = 'X';
    updateMessage();
    const cells = document.getElementsByClassName('cell');
    for (let i = 0; i < cells.length; i++) {
        cells[i].innerText = '';
    }
}

resetGame();
